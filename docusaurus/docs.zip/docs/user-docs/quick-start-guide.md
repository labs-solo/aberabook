---
displayed_sidebar: userDocsSidebar
sidebar_label: "Quick Start Guide"
---

# Quick Start Guide

_AquaBera is launching on Bartio Testnet Soon! Be ready to automate your liquidity._

In the meantime, familiarize yourself with key concepts and prepare to maximize your returns:

- [Prerequisites](./prerequisites)
- [What is AquaBera?](./what-is-aquabera)
- [AquaBera Features & Benefits](./features-benefits)
