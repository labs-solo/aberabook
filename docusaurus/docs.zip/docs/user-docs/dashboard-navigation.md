---
displayed_sidebar: userDocsSidebar
sidebar_label: "Navigating the Dashboard"
---

# Navigating the Dashboard

_AquaBera is launching on Bartio Testnet Soon! Be ready to automate your liquidity._

Until then, explore essential tools and features:

- [Kodiak AMM Overview](./kodiak-amm-overview)
- [Managing Liquidity Pools](./manage-liquidity-pools)
- [How PoL Works](./pol-mechanics)
