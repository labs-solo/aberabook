---
displayed_sidebar: userDocsSidebar
sidebar_label: "Introduction to Community"
---

# Introduction to Community

_AquaBera is launching on Bartio Testnet Soon!_

In the meantime, refer to the [User Guide](./intro) for essential information.

We'll soon introduce ways to engage with the AquaBera community, participate in governance, and contribute to the ecosystem.
