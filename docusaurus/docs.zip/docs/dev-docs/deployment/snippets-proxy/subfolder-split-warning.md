:::note Subfolder split is not supported
Using subfolder split (eg: `https://example.com/dashboard` and `https://example.com/api`) are not supported nor recommended with Strapi. It's advised that you either use subdomains (eg: `https://api.example.com`) or subfolder unified (eg: `https://example.com/strapi/dashboard` and `https://example.com/strapi/api`).
:::
