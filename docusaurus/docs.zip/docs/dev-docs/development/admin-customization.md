---
title: Admin panel customization
displayed_sidebar: devDocsSidebar
---

(Coming soon… — please visit [docs.strapi.io](https://docs.strapi.io/developer-docs/latest/development/admin-customization.html#logos) in the meantime.)