:::strapi Have you considered the Entity Service API?
 The [Entity Service API](/dev-docs/api/entity-service) is the recommended API to interact with your application's database. Only use QueryEngine if EntityService does not cover your use case.
:::