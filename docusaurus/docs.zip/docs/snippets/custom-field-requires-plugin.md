Registering a custom field through a plugin requires creating and enabling a plugin (see [Plugins development](/dev-docs/plugins-development#create-a-plugin)).
