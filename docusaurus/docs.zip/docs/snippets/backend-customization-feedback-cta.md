:::callout 💬 Strapi team needs you to improve this documentation!
We are currently reworking the Backend Customization section of the Strapi documentation. If you would like to help, please feel free to fill in [this form](https://forms.gle/YS8zGUrG6FQ72dmh8) to share with us your opinions, needs and requests.
:::
