JavaScript query (built with the qs library):
