Run the following command in your project root directory to restart the application:

<Tabs groupId="yarn-npm">

<TabItem value="yarn" label="yarn">

```bash
yarn develop
```

</TabItem>

<TabItem value="npm" label="npm">

```bash
npm run develop
```

</TabItem>

</Tabs>
