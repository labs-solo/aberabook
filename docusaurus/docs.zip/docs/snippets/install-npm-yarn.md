Install the upgraded version:

<Tabs groupId="yarn-npm">

<TabItem value="yarn" label="yarn">

```bash
yarn
```

</TabItem>

<TabItem value="npm" label="npm">

```bash
npm install
```

</TabItem>

</Tabs>

:::tip
If the operation doesn't work, try removing your `yarn.lock` or `package-lock.json`. If that doesn't help, remove the `node_modules` folder as well and try again.
:::
