| Hardware | Recommended | Minimum |
|----------|-------------|---------|
| CPU      |  2+ cores   | 1 core  |
| Memory   | 4GB+        | 2GB     |
| Disk     |  32GB+      | 8GB     |