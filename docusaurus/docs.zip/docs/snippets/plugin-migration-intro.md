This guide is part of the [v4 plugin migration guide](/dev-docs/migration/v3-to-v4/plugin-migration.md) designed to help you migrate a plugin from Strapi v3.6.x to v4.0.x.
