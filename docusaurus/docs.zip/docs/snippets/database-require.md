| Database   | Recommended | Minimum |
| ---------- | ----------- | ------- |
| MySQL      | 8.0         | 5.7.8   |
| MariaDB    | 10.6        | 10.3    |
| PostgreSQL | 14.0        | 11.0    |
| SQLite     | 3           | 3       |