:::prerequisites

The Content Source Map plugin requires:

- A Strapi <EnterpriseBadge /> licence for the self-hosted version of Strapi, or a [Strapi Cloud](https://strapi.io/pricing-cloud) plan
- A website deployed on [Vercel](https://vercel.com/docs/workflow-collaboration/visual-editing) with a Vercel Pro or Enterprise plan

:::
