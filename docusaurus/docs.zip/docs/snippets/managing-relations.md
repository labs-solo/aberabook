:::tip
In the `data` object, relations can be managed with the `connect`, `disconnect`, and `set` parameters using the syntax described for the REST API (see [managing relations](/dev-docs/api/rest/relations)).
:::
