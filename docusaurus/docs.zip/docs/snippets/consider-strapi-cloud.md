:::callout ☁️ Strapi Cloud

You can also use [Strapi Cloud](/cloud/intro) to quickly deploy and host your project.

:::
