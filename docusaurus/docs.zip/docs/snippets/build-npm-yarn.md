Run the following command in your project root directory to rebuild Strapi's admin panel:

<Tabs groupId="yarn-npm">

<TabItem value="yarn" label="yarn">

```bash
yarn build
```

</TabItem>

<TabItem value="npm" label="npm">

```bash
npm run build
```

</TabItem>

</Tabs>
