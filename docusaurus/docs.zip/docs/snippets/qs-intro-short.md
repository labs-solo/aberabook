Strapi takes advantage of the ability of [the `qs` library](https://github.com/ljharb/qs) to parse nested objects to create more complex queries.
Use `qs` directly to generate complex queries instead of creating them manually.
