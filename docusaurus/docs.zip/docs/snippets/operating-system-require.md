| Operating System |  Recommended |Minimum |
|------------------|-------------|---------|
| Ubuntu (LTS)     | 22.04       | 20.04   |
| Debian           |  11.x       | 10.x    |
| CentOS/RHEL      |  9.x        | 8.x     |
| macOS            |  11.0       | 10.15   |
| Windows Desktop  |  11         | 10      |
| Windows Server   | 2022        | 2019    |